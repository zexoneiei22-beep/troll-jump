// ปรับค่า native: เต็มจอ, รองรับจอรอยบาก, หมุนจอได้, ซ่อนแถบสถานะ iOS
const fs = require('fs');
const edit = (f, fn) => { if (!fs.existsSync(f)) return; const a = fs.readFileSync(f, 'utf8'), b = fn(a); if (a !== b) { fs.writeFileSync(f, b); console.log('patched', f); } };
edit('android/app/src/main/AndroidManifest.xml', s =>
  /screenOrientation/.test(s) ? s : s.replace('<activity', '<activity\n            android:screenOrientation="fullUser"'));
edit('android/app/src/main/res/values/styles.xml', s =>
  /windowFullscreen/.test(s) ? s : s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,
    '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>'));
edit('ios/App/App/Info.plist', s => {
  s = s.replace(/(<key>UIViewControllerBasedStatusBarAppearance<\/key>\s*)<true\/>/, '$1<false/>');
  if (!/UIStatusBarHidden/.test(s)) s = s.replace(/<\/dict>\s*<\/plist>/, '\t<key>UIStatusBarHidden</key>\n\t<true/>\n</dict>\n</plist>');
  return s;
});
