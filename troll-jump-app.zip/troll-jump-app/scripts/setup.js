// Usage: node scripts/setup.js [android|ios|all]
const { execSync } = require('child_process');
const fs = require('fs');
const run = c => { console.log('> ' + c); execSync(c, { stdio: 'inherit' }); };
const t = process.argv[2] || 'all';
const doA = t === 'android' || t === 'all';
const doI = (t === 'ios' || t === 'all') && process.platform === 'darwin';
if ((t === 'ios' || t === 'all') && !doI) console.log('(ข้าม iOS: ต้องใช้ macOS + Xcode)');
if (doA && !fs.existsSync('android')) run('npx cap add android');
if (doI && !fs.existsSync('ios')) run('npx cap add ios');
run('npx capacitor-assets generate --assetPath resources' + (doA ? '' : ' --ios') + (doI ? '' : ' --android'));
run('node scripts/patch-native.js');
run('npx cap sync');
console.log('\nเสร็จแล้ว: รัน npx cap open android หรือ npx cap open ios');
